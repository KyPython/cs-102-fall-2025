
public class JavaReview {

    public static final int DAYS_IN_WEEK = 7;

    public static void line(int count) {
        for (int i = 0; i < count; i++) {
            System.out.print("*");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        line(3);
        line(7);
        line(13);
        line(40);
    }

    public static void main12(String[] args) {

        final double INTEREST_RATE = 7.5;
        System.out.println("Days in week " + DAYS_IN_WEEK);
        System.out.println("Days in week " + JavaReview.DAYS_IN_WEEK);

        System.out.println("INTEREST_RATE = " + INTEREST_RATE);
    }


    public static void main11(String[] args) {
        // Nested Loops
        for (int i = 1; i <= 4; i++) {
            for (int j = 1; j <= 5; j++) {
                System.out.print(i * j + "\t");
            }
            System.out.println();
        }
    }

    public static void main10(String[] args) {
        // Loops
        int length = 4;
        for (int i = 1; i <= length; i++) {
            System.out.println("i = " + i);

            if( i == (length / 2)){
                System.out.println("\n");
            }
        }
    }

    public static void main9(String[] args) {
        // Loops
        for (int i = 1; i <= 10; i++) {
            System.out.println("i = " + i);

            if( i == 5){
                System.out.println("\n");
            }
        }
    }
    public static void main8(String[] args) {
        // Increment & Decrement
        int x = 2;
        System.out.println("x = " + x);
        x++;
        System.out.println("x = " + x);
// 3
        System.out.println(x++ + ++x); // 8 ?

        double gpa = 3.5;
        gpa--;
        System.out.println("gpa = " + gpa);

        x+=3;
        System.out.println("x = " + x);

        int y = 2;
        y *= 2;
        System.out.println("y = " + y);
    }

    public static void main7(String[] args) {
        // Type Casting
        double result = (double) 19 / 5;
        System.out.println("result = " + result);

        int result2 = (int) result;
        System.out.println("result2 = " + result2);

        int x = (int) Math.pow(10, 3);
        System.out.println("x = " + x);
    }

    public static void main6(String[] args) {
        // Variables
        double myGPA = 3.95;
        int x = (11 % 3) + 12;

        System.out.println("x = " + x);
        System.out.println("myGPA = " + myGPA);

    }

    public static void main5(String[] args) {
        // String concatenation
        System.out.println("hello" + 42); // is it hello42 ?
        System.out.println(1 + 2 + "abc"); // is it 3abc?
        System.out.println("abc" + 1 + 2); // is it abc3?
        System.out.println("abc" + (1 + 2)); // is it abc3?
    }

    public static void main4(String[] args) {
        System.out.println(1 + 3 * 4); // Is it 16 ?
    }

    public static void main3(String[] args) {

        System.out.println(14 / 3);
        System.out.println(14.0 / 3);
        System.out.println(14 / 3.0);
        System.out.println(14.0 / 3.0);
    }

    public static void main2(String[] args) {

        System.out.println("Welcome, CS102!!!");
        System.out.println("Date: Sept. 12");

        printWarning();

        JavaReview.printWarning();
    }

    /**
     * A void method that prints a warning.
     */
    public static void printWarning() {
        System.out.println("This is a warning...");
    }
}
